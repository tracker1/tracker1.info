﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;
using System.Web.Compilation;
using System.Web.Mvc;

//duplication of System.Web.Mvc.BuildManagerWrapper

namespace MySite.Web.Engine
{
	internal interface IBuildManager
	{
		object CreateInstanceFromVirtualPath(string virtualPath, Type requiredBaseType);
		ICollection GetReferencedAssemblies();
	}

	internal sealed class BuildManagerWrapper : IBuildManager
	{
		#region IBuildManager Members
		object IBuildManager.CreateInstanceFromVirtualPath(string virtualPath, Type requiredBaseType)
		{
			return BuildManager.CreateInstanceFromVirtualPath(virtualPath, requiredBaseType);
		}

		ICollection IBuildManager.GetReferencedAssemblies()
		{
			return BuildManager.GetReferencedAssemblies();
		}
		#endregion
	}
}
