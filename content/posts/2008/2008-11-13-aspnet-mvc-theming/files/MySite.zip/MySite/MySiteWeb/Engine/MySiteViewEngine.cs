﻿using System;
using System.Globalization;
using System.Linq;
using System.Web.Mvc;
using MySite.Web.Engine;

/*
Based on Chris Pietschmann's View Engine
http://pietschsoft.com/post/2008/08/Custom-Themes-in-ASPNET-MVC-Updated-for-Preview-5.aspx
*/

namespace MySite.Web.Engine
{
	public class MySiteViewEngine : System.Web.Mvc.WebFormViewEngine
	{
		public MySiteViewEngine()
		{
			base.ViewLocationFormats = new string[] {
				"~/Themes/{2}/Views/{1}/{0}.aspx",
				"~/Themes/{2}/Views/{1}/{0}.ascx",
				"~/Themes/{2}/Views/Shared/{0}.aspx",
				"~/Themes/{2}/Views/Shared/{0}.ascx"
			};

			base.MasterLocationFormats = new string[] {
				"~/Themes/{2}/Views/{1}/{0}.master",
				"~/Themes/{2}/Views/Shared/{0}.master"
			};

			base.PartialViewLocationFormats = new string[] {
				"~/Themes/{2}/Views/{1}/{0}.aspx",
				"~/Themes/{2}/Views/{1}/{0}.ascx",
				"~/Themes/{2}/Views/Shared/{0}.aspx",
				"~/Themes/{2}/Views/Shared/{0}.ascx"
			};
		}

		protected override IView CreateView(ControllerContext controllerContext, string viewPath, string masterPath)
		{
			return new MySiteView(viewPath, masterPath);
		}
		
		public override ViewEngineResult FindView(ControllerContext controllerContext, string viewName, string masterName)
		{
			if (controllerContext == null)
				throw new ArgumentNullException("controllerContext");

			if (string.IsNullOrEmpty(viewName))
				throw new ArgumentException("Value is required.", "viewName");

			string themeName = this.GetThemeToUse(controllerContext);

			string[] searchedViewLocations;
			string[] searchedMasterLocations;

			string controllerName = controllerContext.RouteData.GetRequiredString("controller");

			string viewPath = this.GetPath(this.ViewLocationFormats, viewName, controllerName, themeName, out searchedViewLocations);

			string masterPath = this.GetPath(this.MasterLocationFormats, masterName, controllerName, themeName, out searchedMasterLocations);

			if (!(string.IsNullOrEmpty(viewPath)) && (!(masterPath == string.Empty) || string.IsNullOrEmpty(masterName)))
				return new ViewEngineResult(this.CreateView(controllerContext, viewPath, masterPath), this);
			
			return new ViewEngineResult(searchedViewLocations.Union<string>(searchedMasterLocations));
		}

		public override ViewEngineResult FindPartialView(ControllerContext controllerContext, string partialViewName)
		{
			if (controllerContext == null)
				throw new ArgumentNullException("controllerContext");

			if (string.IsNullOrEmpty(partialViewName))
				throw new ArgumentException("Value is required.", partialViewName);

			string themeName = this.GetThemeToUse(controllerContext);

			string[] searchedLocations;

			string controllerName = controllerContext.RouteData.GetRequiredString("controller");

			string partialPath = this.GetPath(this.PartialViewLocationFormats, partialViewName, controllerName, themeName, out searchedLocations);

			if (string.IsNullOrEmpty(partialPath))
				return new ViewEngineResult(searchedLocations);

			return new ViewEngineResult(this.CreatePartialView(controllerContext, partialPath), this);
		}

		private string GetThemeToUse(ControllerContext controllerContext)
		{
			string themeName = controllerContext.HttpContext.Items["themeName"] as string;
			if (themeName == null) themeName = "Default";
			return themeName;
		}

		private string GetPath(string[] locations, string viewName, string controllerName, string themeName, out string[] searchedLocations)
		{
			string path = null;

			searchedLocations = new string[locations.Length*2];

			for (int i = 0; i < locations.Length; i++)
			{
				path = string.Format(CultureInfo.InvariantCulture, locations[i], viewName, controllerName, themeName);
				if (this.VirtualPathProvider.FileExists(path))
				{
					searchedLocations = new string[0];
					return path;
				}
				searchedLocations[i] = path;
			}

			//try default theme, for a fallback
			for (int i = 0; i < locations.Length; i++)
			{
				path = string.Format(CultureInfo.InvariantCulture, locations[i], viewName, controllerName, "Default");
				if (this.VirtualPathProvider.FileExists(path))
				{
					searchedLocations = new string[0];
					return path;
				}
				searchedLocations[i + locations.Length] = path;
			}

			return null;
		}
	}
}
