﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using MySite.Web.Engine;

namespace MySite.Web
{
	// Note: For instructions on enabling IIS6 or IIS7 classic mode, 
	// visit http://go.microsoft.com/?LinkId=9394801

	public class MvcApplication : System.Web.HttpApplication
	{
		public static void RegisterRoutes(RouteCollection routes)
		{
			routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

			routes.MapRoute(
				"Default",											  // Route name
				"{controller}/{action}/{id}",						   // URL with parameters
				new { controller = "Home", action = "Index", id = "" },  // Parameter defaults
				new string[] { "MySite.Web.Controllers" } //namespaces
			);

		}

		protected void Application_Start()
		{
			//Register the routes needed for MVC
			RegisterRoutes(RouteTable.Routes);

			// Replace the Default WebFormViewEngine with out custom WebFormThemeViewEngine
			ViewEngines.Engines.Clear();
			ViewEngines.Engines.Add(new MySiteViewEngine());
		}

		protected void Application_BeginRequest(Object Sender, EventArgs e)
		{
			SetTheme();
		}

		private void SetTheme()
		{
			//set the theme for the ViewEngine to utilize.
			HttpContext context = HttpContext.Current;
			if (context.Items.Contains("theme")) context.Items.Remove("theme");
			context.Items.Add(
				"themeName",
				CheckTheme(context.Request.QueryString["theme"])
					?? CheckTheme(context.Request.Form["theme"])
					?? CheckTheme(context.Request.Headers["theme"])
					?? CheckTheme((context.Request.Cookies["theme"] == null) ? "" : context.Request.Cookies["theme"].Value)
					?? CheckTheme((context.Session == null) ? "" : context.Session["theme"] as string)
					?? CheckTheme(ConfigurationSettings.AppSettings["theme"])
					?? "Default"
			);
		}
		private string CheckTheme(string themeName)
		{
			if (!string.IsNullOrEmpty(themeName))
			{
				var path = HttpContext.Current.Server.MapPath(string.Format(
					"~/Themes/{0}",
					themeName
				));
				if (Directory.Exists(path))
					return themeName;
			}
			return null;
		}
		private string CheckTheme(HttpCookie cookie) {
			if (cookie != null)
				return CheckTheme(cookie.Value);
			return null;
		}
		}
}