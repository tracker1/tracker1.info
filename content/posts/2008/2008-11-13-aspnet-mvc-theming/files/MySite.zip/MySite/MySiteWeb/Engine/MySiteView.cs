﻿using System;
using System.Globalization;
using System.IO;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace MySite.Web.Engine
{
	public class MySiteView : System.Web.Mvc.WebFormView 
	{


#region BuildManager	
		private IBuildManager _buildManager;	
		internal IBuildManager BuildManager
		{
			get
			{
				if (_buildManager == null)
				{
					_buildManager = new BuildManagerWrapper();
				}
				return _buildManager;
			}
			set
			{
				_buildManager = value;
			}
		}
#endregion


        public MySiteView(string viewPath, string masterPath) : base(viewPath, masterPath) {
        }

		override public void Render(ViewContext viewContext, TextWriter writer)
		{
			if (viewContext == null)
			{
				throw new ArgumentNullException("viewContext");
			}

			object viewInstance = BuildManager.CreateInstanceFromVirtualPath(ViewPath, typeof(object));
			if (viewInstance != null)
			{
				ViewPage viewPage = viewInstance as ViewPage;
				if (viewPage != null)
				{
					RenderViewPage(viewContext, viewPage);
					return;
				}
			}

			base.Render(viewContext, writer);
		}

private void RenderViewPage(ViewContext context, ViewPage page)
{
	if (!String.IsNullOrEmpty(MasterPath)) {
		page.MasterLocation = MasterPath;
	} else {
		if (HttpContext.Current.Items["themeName"].ToString() != "Default" && page.TemplateSourceDirectory.Contains("/Themes/Default/"))
			page.PreInit += new EventHandler(delegate(object sender, EventArgs e){
				//test for Default theme path, and replace with current theme
				string defaultthemepath = string.Format("{0}Themes/Default/", page.Request.ApplicationPath);
				if (!string.IsNullOrEmpty(page.MasterPageFile) && page.MasterPageFile.ToLower().StartsWith(defaultthemepath.ToLower()))
				{
					string newMaster = string.Format(
						"~/Themes/{0}/{1}",
						HttpContext.Current.Items["themeName"],
						page.MasterPageFile.Substring(defaultthemepath.Length)
					);
					if (File.Exists(page.Server.MapPath(newMaster)))
						page.MasterLocation = newMaster;
				}
			});
	}

	page.ViewData = context.ViewData;
	page.RenderView(context);
}


	}
}
